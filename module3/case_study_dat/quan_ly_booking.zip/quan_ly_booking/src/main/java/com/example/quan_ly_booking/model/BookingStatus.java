package com.example.quan_ly_booking.model;

public class BookingStatus {
    private int bookingStatusId;
    private String bookingStatusName;

}
